import numpy as np
import pandas as pd
from sklearn.preprocessing import LabelEncoder

def generate_synthetic_data(n_samples=1000, random_state=42):
    np.random.seed(random_state)

    # Demographics
    age = np.random.randint(18, 90, n_samples)
    gender = np.random.choice(['Male', 'Female'], n_samples, p=[0.48, 0.52])

    # BMI: influenced by age
    bmi = np.clip(np.random.normal(27 + age * 0.05, 5, n_samples), 15, 50)

    # Blood Pressure: higher with age and bmi
    systolic_bp = np.clip(
        100 + 0.4 * age + 0.5 * (bmi - 25) + np.random.normal(0, 10, n_samples),
        80, 200
    ).astype(int)

    # Cholesterol
    cholesterol = np.clip(
        150 + 0.6 * age + 0.8 * (bmi - 25) + np.random.normal(0, 20, n_samples),
        100, 320
    ).astype(int)

    # Glucose
    glucose = np.clip(
        80 + 0.3 * age + 0.4 * (bmi - 25) + np.random.normal(0, 15, n_samples),
        60, 250
    ).astype(int)

    # Lifestyle
    smoking = np.random.choice(['Yes', 'No'], n_samples, p=[0.25, 0.75])
    physical_activity = np.random.choice(
        ['Low', 'Moderate', 'High'], n_samples, p=[0.35, 0.45, 0.20]
    )
    family_history = np.random.choice(['Yes', 'No'], n_samples, p=[0.35, 0.65])
    prev_visits = np.random.poisson(2, n_samples).clip(0, 15)

    # ── Target 1: Medical Expenses (Linear Regression) ──
    smoking_factor = np.where(smoking == 'Yes', 8000, 0)
    activity_factor = np.where(physical_activity == 'High', -2000,
                        np.where(physical_activity == 'Moderate', -500, 1500))
    history_factor = np.where(family_history == 'Yes', 3000, 0)
    gender_factor  = np.where(gender == 'Female', 1000, 0)

    medical_expenses = (
        2000
        + 150 * age
        + 300 * bmi
        + 50 * systolic_bp
        + 30 * cholesterol
        + 40 * glucose
        + smoking_factor
        + activity_factor
        + history_factor
        + gender_factor
        + 500 * prev_visits
        + np.random.normal(0, 2000, n_samples)
    ).clip(1000, 150000).round(2)

    # ── Target 2: Disease Presence (Decision Tree) ──
    risk_score = (
        (age > 50).astype(int) * 2
        + (bmi > 30).astype(int) * 2
        + (systolic_bp > 140).astype(int) * 2
        + (cholesterol > 240).astype(int) * 2
        + (glucose > 126).astype(int) * 3
        + (smoking == 'Yes').astype(int) * 2
        + (physical_activity == 'Low').astype(int)
        + (family_history == 'Yes').astype(int) * 2
        + (prev_visits > 3).astype(int)
    )
    disease_prob = 1 / (1 + np.exp(-(risk_score - 7) * 0.5))
    disease_presence = (np.random.random(n_samples) < disease_prob).astype(int)

    # ── Target 3: Risk Category (KNN) ──
    risk_category = pd.cut(
        risk_score,
        bins=[-1, 3, 6, 10, 20],
        labels=['Low Risk', 'Medium Risk', 'High Risk', 'Critical Risk']
    )

    df = pd.DataFrame({
        'Age': age,
        'Gender': gender,
        'BMI': bmi.round(1),
        'Blood_Pressure': systolic_bp,
        'Cholesterol': cholesterol,
        'Glucose': glucose,
        'Smoking': smoking,
        'Physical_Activity': physical_activity,
        'Family_History': family_history,
        'Previous_Visits': prev_visits,
        'Medical_Expenses': medical_expenses,
        'Disease_Presence': disease_presence,
        'Risk_Category': risk_category
    })

    return df


def encode_features(df):
    """Return encoded dataframe + label encoders dict"""
    df_enc = df.copy()
    encoders = {}
    for col in ['Gender', 'Smoking', 'Physical_Activity', 'Family_History']:
        le = LabelEncoder()
        df_enc[col] = le.fit_transform(df_enc[col].astype(str))
        encoders[col] = le
    return df_enc, encoders


if __name__ == "__main__":
    df = generate_synthetic_data(1000)
    print(df.head())
    print(df.describe())
    print(df['Risk_Category'].value_counts())
    df.to_csv('synthetic_healthcare_data.csv', index=False)
    print("Dataset saved.")
