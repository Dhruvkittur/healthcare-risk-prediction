import numpy as np
import pandas as pd
import joblib, os
from sklearn.linear_model import LinearRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.cluster import KMeans
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.metrics import (
    mean_absolute_error, mean_squared_error, r2_score,
    accuracy_score, classification_report, confusion_matrix,
    silhouette_score
)
from data_generator import generate_synthetic_data, encode_features

MODEL_DIR = "models"
os.makedirs(MODEL_DIR, exist_ok=True)

FEATURES = [
    'Age', 'Gender', 'BMI', 'Blood_Pressure', 'Cholesterol',
    'Glucose', 'Smoking', 'Physical_Activity', 'Family_History', 'Previous_Visits'
]


def train_all(n_samples=1500):
    print("Generating dataset …")
    df = generate_synthetic_data(n_samples)
    df_enc, encoders = encode_features(df)

    # ── Risk Category encoding ──
    rc_le = LabelEncoder()
    df_enc['Risk_Category_enc'] = rc_le.fit_transform(df['Risk_Category'].astype(str))
    joblib.dump(rc_le, f"{MODEL_DIR}/risk_category_le.pkl")
    joblib.dump(encoders, f"{MODEL_DIR}/feature_encoders.pkl")
    df.to_csv(f"{MODEL_DIR}/dataset.csv", index=False)

    X = df_enc[FEATURES].values

    # ── Scaler ──
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)
    joblib.dump(scaler, f"{MODEL_DIR}/scaler.pkl")

    metrics = {}

    # ══ 1. Linear Regression – Medical Expenses ══
    y_lr = df_enc['Medical_Expenses'].values
    X_tr, X_te, y_tr, y_te = train_test_split(X_scaled, y_lr, test_size=0.2, random_state=42)
    lr = LinearRegression()
    lr.fit(X_tr, y_tr)
    y_pred = lr.predict(X_te)
    metrics['linear_regression'] = {
        'MAE':  round(mean_absolute_error(y_te, y_pred), 2),
        'MSE':  round(mean_squared_error(y_te, y_pred), 2),
        'RMSE': round(np.sqrt(mean_squared_error(y_te, y_pred)), 2),
        'R2':   round(r2_score(y_te, y_pred), 4),
        'y_test': y_te.tolist(),
        'y_pred': y_pred.tolist()
    }
    joblib.dump(lr, f"{MODEL_DIR}/linear_regression.pkl")
    print("LR done – R²:", metrics['linear_regression']['R2'])

    # ══ 2. Decision Tree – Disease Presence ══
    y_dt = df_enc['Disease_Presence'].values
    X_tr, X_te, y_tr, y_te = train_test_split(X_scaled, y_dt, test_size=0.2, random_state=42)
    dt = DecisionTreeClassifier(max_depth=8, min_samples_split=20, random_state=42)
    dt.fit(X_tr, y_tr)
    y_pred = dt.predict(X_te)
    metrics['decision_tree'] = {
        'Accuracy':  round(accuracy_score(y_te, y_pred), 4),
        'Report':    classification_report(y_te, y_pred, output_dict=True),
        'Confusion': confusion_matrix(y_te, y_pred).tolist(),
        'y_test':    y_te.tolist(),
        'y_pred':    y_pred.tolist()
    }
    joblib.dump(dt, f"{MODEL_DIR}/decision_tree.pkl")
    print("DT done – Accuracy:", metrics['decision_tree']['Accuracy'])

    # ══ 3. KNN – Risk Category ══
    y_knn = df_enc['Risk_Category_enc'].values
    X_tr, X_te, y_tr, y_te = train_test_split(X_scaled, y_knn, test_size=0.2, random_state=42)
    knn = KNeighborsClassifier(n_neighbors=7, metric='euclidean')
    knn.fit(X_tr, y_tr)
    y_pred = knn.predict(X_te)
    metrics['knn'] = {
        'Accuracy':  round(accuracy_score(y_te, y_pred), 4),
        'Report':    classification_report(y_te, y_pred, output_dict=True),
        'Confusion': confusion_matrix(y_te, y_pred).tolist(),
        'Classes':   rc_le.classes_.tolist()
    }
    joblib.dump(knn, f"{MODEL_DIR}/knn.pkl")
    print("KNN done – Accuracy:", metrics['knn']['Accuracy'])

    # ══ 4. K-Means – Patient Segments ══
    kmeans = KMeans(n_clusters=4, random_state=42, n_init=10)
    cluster_labels = kmeans.fit_predict(X_scaled)
    sil = round(silhouette_score(X_scaled, cluster_labels), 4)
    df['Cluster'] = cluster_labels
    metrics['kmeans'] = {
        'Silhouette': sil,
        'Inertia':    round(kmeans.inertia_, 2),
        'n_clusters': 4
    }
    joblib.dump(kmeans, f"{MODEL_DIR}/kmeans.pkl")
    df.to_csv(f"{MODEL_DIR}/dataset_with_clusters.csv", index=False)
    print("KMeans done – Silhouette:", sil)

    joblib.dump(metrics, f"{MODEL_DIR}/metrics.pkl")
    print("\nAll models saved to", MODEL_DIR)
    return metrics


if __name__ == "__main__":
    train_all()
